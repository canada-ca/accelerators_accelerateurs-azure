﻿Configuration winrm
{
    Node "localhost"
    {
        Script OpenFirewalls {
            GetScript = { return $true}
            SetScript = {
               #json for winrm doesn't seem to open the correct firewall rules
               Enable-PSRemoting -force
               netsh advfirewall firewall set rule group="Windows Management Instrumentation (WMI)" new enable=yes
               netsh advfirewall firewall add rule name="WinRM-HTTPS" dir=in localport=5986 protocol=TCP action=allow remoteip=any
               netsh advfirewall firewall add rule name="WinRM-HTTP" dir=in localport=5985 protocol=TCP action=allow remoteip=any
               New-NetFirewallRule -Name "Allow GetService" -DisplayName "Get Service 445" -Enabled True -Profile Any -Action Allow -Direction Inbound -LocalPort 445 -Protocol TCP
               Enable-WSManCredSSP -Role Client -DelegateComputer "*" -Force
               Set-Item "WSMAN:\localhost\service\auth\credssp" -Value $true 
            }
            TestScript = {
            #Test will be cleaned up at a later date to use passed in parameters.  Code will be similar to bellow
             
            #$block = {
            #    Write-Host ("hello, world: {0}, {1}" -f $env:USERNAME, (hostname))
            #    }
            #    $serverName = ""
            #    $username = ""
            #    $password = ""   
            #    $adjPwd = $password | ConvertTo-SecureString -asPlainText -Force
            #    $testCred = (New-Object System.Management.Automation.PSCredential($username,$adjPwd))    
            #    $choice = "credentialB"
            #    switch ($choice)
            #    {
            #    "basic"       { Invoke-Command $block }
            #    "remote"      { Invoke-Command $block -computername $serverName }
            #    "credentialA" { Invoke-Command $block -computername $serverName -credential $testCred  }
            #    "credentialB" { Invoke-Command $block -computername $serverName -credential $testCred  -Authentication Credssp }
            #    "session"     { 
            #        $testSession = New-PSSession -computername $serverName -credential $testCred -Authentication Credssp
            #        if ($testSession) { Invoke-Command $block -Session $testSession; Remove-PSSession $testSession }
            #        }
            #    }
               return $true
            }
        }

    }
}